package ug.lab04.procesor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcesorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcesorApplication.class, args);
	}

}
